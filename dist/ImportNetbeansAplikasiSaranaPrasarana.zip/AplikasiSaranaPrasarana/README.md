# APLIKASI SARANA PRASRANA 🗄️
Aplikasi untuk mengatur peminjaman dan pelaporan sarana prasarana sebagai bentuk pemenuhan tugas mata kuliah Algoritma dan Pemrograman 2. Dengan fitur yang mencakup:
- Pengelolaan Aset dan Fasilitas
- Penjadwalan perawatan
- Pelaporan kerusakan
- Peminjaman Aset dan Fasilitas

Pengelolaan Sarana & Prasarana menjadi lebih efisien dan efektif yang tentunya menghemat waktu dan tenaga.

----

## 🔧 Cara Penggunaan
### 1. Buka aplikasi menggunakan `Aplikasi Sarana Prasarana.bat`
![Bat sarana prasarana](Gambar/bat.png)

---

### 2. atau buka pada folder `dist` melalui `AplikasiSaranaPrasarana.jar`
![Jar sarana prasarana](Gambar/jar.png)

---

### 3. Pada login bukalah aplikasi menggunakan user dibawah
-   **Admin**: Username dan password = `q`
-   **Petugas**: Username dan password = `a`
-   **User**: Username dan password = `z`

![Login](Gambar/login.png)
