# AplikasiSaranaPrasarana
Aplikasi untuk mengatur peminjaman dan pelaporan sarana prasarana sebagai bentuk pemenuhan tugas mata kuliah Algoritma dan Pemrograman 2
